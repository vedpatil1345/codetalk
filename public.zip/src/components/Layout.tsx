import React from "react";
import  NavBar  from "./NavBar";
import { GradientBackground } from "./GradientBackground";
import { ThemeProvider } from "./theme/ThemeProvider";
import { Outlet } from "react-router-dom";
import { ProtectedRoute } from "@/components/auth/ProtectedRoute";

export const Layout: React.FC = () => {
  return (
    <ThemeProvider storageKey="vite-ui-theme">
      <GradientBackground className="h-screen overflow-auto">
        <NavBar />
        <div className="dark:backdrop-blur-sm  min-h-screen overflow-auto mt-12">
        <ProtectedRoute>
          <Outlet />
        </ProtectedRoute>
        </div>
      </GradientBackground>
    </ThemeProvider>
  );
};
