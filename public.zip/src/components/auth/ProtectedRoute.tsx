import { useAuth } from "@/hooks/useAuth";
import React from "react";
import { useNavigate,useLocation } from "react-router-dom";


export const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user } = useAuth();
    const navigate = useNavigate();
    const location = useLocation();
    React.useEffect(() => {
      if (!user) {
        navigate('/auth');
      }
    }, [user, navigate]);
  
    return user||location.pathname.startsWith('/auth') ? <>{children}</> : null;
  };