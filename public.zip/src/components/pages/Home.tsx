import React, { useState, useEffect } from "react";

import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useNavigate } from "react-router-dom";
import { DiscordLogoIcon } from "@radix-ui/react-icons"

const words = ["Talk", "AI", "Future", "Dreams", "Innovation", "Possibilities"];
const TYPING_SPEED = 150;
const DELETING_SPEED = 100;
const PAUSE_TIME = 2000;

export function TypewriterEffect() {
  const [text, setText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);
  const [wordIndex, setWordIndex] = useState(0);
  const [delta, setDelta] = useState(TYPING_SPEED);

  useEffect(() => {
    const timeout = setTimeout(() => {
      const currentWord = words[wordIndex];

      if (isDeleting) {
        setText(currentWord.substring(0, text.length - 1));
        setDelta(DELETING_SPEED);
      } else {
        setText(currentWord.substring(0, text.length + 1));
        setDelta(TYPING_SPEED);
      }

      if (!isDeleting && text === currentWord) {
        setTimeout(() => setIsDeleting(true), PAUSE_TIME);
      } else if (isDeleting && text === "") {
        setIsDeleting(false);
        setWordIndex((prev) => (prev + 1) % words.length);
      }
    }, delta);

    return () => clearTimeout(timeout);
  }, [text, isDeleting, wordIndex, delta]);

  return (
    <span className="text-primary-600 font-bold">
      {text}
      <span className="animate-pulse">|</span>
    </span>
  );
}

export const Home: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="flex flex-col items-center justify-center text-center min-h-screen">
      <h1
        className="text-4xl lg:text-6xl font-bold mb-4 bg-clip-text text-transparent transition-colors duration-300
                   bg-gradient-to-r from-blue-800 via-blue-800 to-blue-800
                   dark:from-blue-500 dark:via-blue-400 dark:to-blue-500"
      >
        Code{'{'}<TypewriterEffect />{'}'}
      </h1>
      <h1 className="text-lg dark:text-white lg:text-2xl mt-6 mb-4 w-[70%] lg:w-full max-w-4xl mx-auto">
        The Online Code Analysis And Debugging Platform
      </h1>
      <p className="text-sm lg:text-lg text-muted-foreground mb-4 w-[70%] lg:w-full max-w-4xl mx-auto">
        Analyze, debug, and optimize your code with AI assistance
      </p>
      <div className="flex justify-center gap-4">
        <Button
          className="bg-blue-500 hover:bg-blue-800 dark:bg-blue-600 dark:hover:bg-blue-800 text-white"
          size="lg"
          onClick={user ? () => navigate("/playground") : () => navigate("/auth")}
        >
          {user ? "CodeRoom" : "Get Started"}
        </Button>
        <Button
          size="lg"
          className="bg-[#5865F2] hover:bg-[#4752C4] text-white font-semibold rounded-md transition-colors"
          onClick={() => window.open('https://discord.gg/Gfs4JNT2', '_blank')}
        >
          <DiscordLogoIcon className="w-6 h-6" />
          <span>Join our Discord server</span>
        </Button>
      </div>
      <div className="block lg:w-[40%] w-[80%] max-w-4xl mx-auto mt-5 items-center rounded-xl">
        <iframe
          className="w-full aspect-video rounded-xl shadow-xl shadow-blue-800/50 dark:shadow-blue-500/50"
          src="https://www.youtube.com/embed/PjIZxKcYCqI?si=ITSptz4PuCUkLfKo"
          title="YouTube video player"
          aria-label="YouTube video player"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          referrerPolicy="strict-origin-when-cross-origin"
          allowFullScreen
        ></iframe>
      </div>
    </div>
  );
};
